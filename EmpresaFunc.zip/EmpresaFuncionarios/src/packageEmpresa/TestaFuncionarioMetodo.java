
package packageEmpresa;


public class TestaFuncionarioMetodo {

    
    public static void main(String[] args) {
        Funcionario f1 = new Funcionario();
        
        f1.aumentaSalario(500);
    }
    
}
