package br.edu.fatec.delivery.cliente;

public record ClienteResponse() {

}
